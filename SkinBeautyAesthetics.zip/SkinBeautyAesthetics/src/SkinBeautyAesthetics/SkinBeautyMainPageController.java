/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package SkinBeautyAesthetics;

import java.net.URL;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.ResourceBundle;
 
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author USER
 */
public class SkinBeautyMainPageController implements Initializable {

    @FXML private TextField ID;
    @FXML private TextField name;
    @FXML private ListView<String> treatmentPlans;
    @FXML private Button submit;
    @FXML private TextArea selectedPlans;
    @FXML private Label totalCostBefore;
    @FXML private Label totalCostAfter;
    @FXML private Button okBtn;
    @FXML private RadioButton lessThan12Months;
    @FXML private RadioButton oneYearAndOver;
    @FXML private ToggleGroup membershipDuration;
    @FXML private Label numofMonthlyTreatment;
 
    public static final String[] planList = {
        "Chemical Peel", "Microneedling", "PRP Therapy",
        "HIFU Treatment", "Hair Treatment", "Manicure", "Pedicure"
    };
    public static final double[] priceList = {
        175.00, 275.00, 100.00, 400.00, 100.00, 20.00, 25.00
    };
 
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ObservableList<String> items = FXCollections.observableArrayList(planList);
        treatmentPlans.setItems(items);
        treatmentPlans.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }
 
    @FXML
    private void submitplan(MouseEvent event) {
        // Validate input
        if (ID.getText().trim().isEmpty() || name.getText().trim().isEmpty()) {
            showAlert("Validation Error", "Please enter both ID and Name.");
            return;
        }
 
        try {
            int customerID = Integer.parseInt(ID.getText().trim());
            String customerName = name.getText().trim();
            ObservableList<Integer> selectedIndices = treatmentPlans.getSelectionModel().getSelectedIndices();
 
            if (selectedIndices.isEmpty()) {
                showAlert("Selection Error", "Please select at least one treatment plan.");
                return;
            }
 
            int[] selectedPlanIndices = selectedIndices.stream().mapToInt(i -> i).toArray();
            boolean isLessThan12Months = lessThan12Months.isSelected();
 
            // Create client and display info
            Client client = new Client(customerID, customerName, selectedPlanIndices, isLessThan12Months);
            displayClientInfo(client);
 
        } catch (NumberFormatException e) {
            showAlert("Input Error", "ID must be a valid number.");
        }
    }
 
    private void displayClientInfo(Client client) {
        StringBuilder planDisplay = new StringBuilder();
        NumberFormat currency = NumberFormat.getCurrencyInstance(Locale.UK);
 
        for (int i : client.getSelectedPlans()) {
            planDisplay.append(String.format("%-25s %7.2f £\n", planList[i], priceList[i]));
        }
 
        selectedPlans.setText(planDisplay.toString());
        totalCostBefore.setText(currency.format(client.getTotalCostRaw()));
        totalCostAfter.setText(currency.format(client.getTotalCostAfterDiscountRaw()));
        numofMonthlyTreatment.setText(client.getTreatmentCount() + " times");
    }
 
    @FXML
    private void clickOKBtn(MouseEvent event) {
        System.exit(0);
    }
 
    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
