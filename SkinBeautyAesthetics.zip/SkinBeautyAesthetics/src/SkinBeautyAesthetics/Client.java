/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SkinBeautyAesthetics;

import java.text.NumberFormat;
import java.util.Locale;

/**
 *
 * @author USER
 */
public class Client {
    private int id;
    private String name;
    private int[] selectedPlans;
    private boolean lessThan12Months;
    private double totalCost;
    private double totalCostAfterDiscount;
 
    public Client(int id, String name, int[] selectedPlans, boolean lessThan12Months) {
        this.id = id;
        this.name = name;
        this.selectedPlans = selectedPlans;
        this.lessThan12Months = lessThan12Months;
        calculateCost();
    }
 
    // Calculate total cost and apply discounts
    private void calculateCost() {
        totalCost = 0;
 
        // Sum up base cost
        for (int planIndex : selectedPlans) {
            totalCost += SkinBeautyMainPageController.priceList[planIndex];
        }
 
        // Determine discount rate based on tiers
        double discountRate = 0;
 
        if (totalCost > 1500) {
            discountRate = 0.15;
        } else if (totalCost > 1000) {
            discountRate = 0.10;
        } else if (totalCost > 500) {
            discountRate = 0.05;
        }
 
        // Add loyalty bonus if membership is 12 months or over
        if (!lessThan12Months) {
            discountRate += 0.05;
        }
 
        // Apply discount
        totalCostAfterDiscount = totalCost - (totalCost * discountRate);
    }
 
    // Getters
    public int getId() {
        return id;
    }
 
    public String getName() {
        return name;
    }
 
    public int[] getSelectedPlans() {
        return selectedPlans;
    }
 
    public boolean isLessThan12Months() {
        return lessThan12Months;
    }
 
    public int getTreatmentCount() {
        return selectedPlans.length;
    }
 
    // Returns formatted currency (e.g., £123.45)
    public String getFormattedTotalCost() {
        return formatCurrency(totalCost);
    }
 
    public String getFormattedTotalCostAfterDiscount() {
        return formatCurrency(totalCostAfterDiscount);
    }
 
    public double getTotalCostRaw() {
        return totalCost;
    }
 
    public double getTotalCostAfterDiscountRaw() {
        return totalCostAfterDiscount;
    }
 
    // Format double as currency string (2 decimal places, £ symbol)
    private String formatCurrency(double amount) {
        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(Locale.UK);
        return currencyFormat.format(amount);
    }
 
    @Override
    public String toString() {
        return "Client ID: " + id +
               ", Name: " + name +
               ", Treatments: " + selectedPlans.length +
               ", Total: " + getFormattedTotalCost() +
               ", After Discount: " + getFormattedTotalCostAfterDiscount();
    }
}   

  